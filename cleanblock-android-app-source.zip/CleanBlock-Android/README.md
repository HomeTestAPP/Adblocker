# 🛡️ CleanBlock Android (Open-Source Adblock App zonder Witte Balken)

Dit is het volledige **open-source Android Studio-project (Kotlin)** voor **CleanBlock Android**.

## Waarom laten normale Android-adblockers witte balken achter?
Systeembrede Android-adblockers (zoals DNS/VPN-adblockers) blokkeren alleen het internetadres van een advertentie. Vanwege de beveiliging van Android mogen zij niet in de HTML-code van andere apps kijken. Daardoor blijft de lege ruimte (`<div>`) op de pagina staan als een grote witte balk.

**CleanBlock Android lost dit op door een eigen Android WebView-engine te combineren met een DOM-collapser:**
1. **Netwerk-blokkade (`shouldInterceptRequest`):** Blokkeert advertentiedomeinen voordat ze data verbruiken.
2. **Automatische Witte-Balken-Inklapper (`WHITE_BAR_COLLAPSER_JS`):** Injecteert bij elke geladen pagina een script dat lege advertentie-containers en hun bovenliggende `<div>`-wrappers op `0px` hoogte zet (`display: none !important`).
3. **🎯 Tik-om-witte-balk-te-verwijderen knop:** Zie je toch een lege balk? Tik bovenin de app op `🎯 Balk` en tik de witte balk op je scherm aan om hem direct te laten verdwijnen.

## Hoe maak en installeer je het `.apk`-bestand op je Android-telefoon?

### Optie A: Via Android Studio (op je pc/laptop)
1. Pak dit `.zip`-bestand uit.
2. Open **Android Studio** en kies **Open** -> selecteer de map `CleanBlock-Android`.
3. Sluit je Android-telefoon aan met een USB-kabel (met *USB-foutopsporing* aan) of klik bovenin het menu op **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Stuur het gemaakte bestand `app-debug.apk` naar je telefoon en tik erop om te installeren.

### Optie B: Zonder pc of Android Studio (Automatisch via GitHub)
Omdat je een open-source app maakt, zit er al een automatische bouw-workflow (`.github/workflows/build-apk.yml`) in dit pakket:
1. Maak een gratis repository aan op **GitHub.com** en upload de uitgepakte bestanden.
2. Klik op het tabblad **Actions** in je GitHub-repository.
3. GitHub bouwt nu automatisch het `.apk`-bestand voor je. Klik onderaan de afgeronde run op **CleanBlock-Android-APK** om het installatiebestand direct op je telefoon te downloaden!
