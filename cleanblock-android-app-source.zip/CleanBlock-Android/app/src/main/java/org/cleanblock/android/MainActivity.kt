package org.cleanblock.android

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var urlInput: EditText
    private lateinit var statsBadge: TextView
    private lateinit var btnTapRemove: Button
    private lateinit var switchAdblock: Switch

    private var blockedCount = 0
    private var adblockEnabled = true

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        urlInput = findViewById(R.id.urlInput)
        statsBadge = findViewById(R.id.statsBadge)
        btnTapRemove = findViewById(R.id.btnTapRemove)
        switchAdblock = findViewById(R.id.switchAdblock)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadsImagesAutomatically = true
        }

        webView.addJavascriptInterface(object {
            @JavascriptInterface
            fun onWhiteBarCollapsed() {
                runOnUiThread {
                    blockedCount++
                    updateBadge()
                }
            }
        }, "AndroidCleanBlock")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString() ?: return null
                if (adblockEnabled && AdBlockEngine.isAdUrl(url)) {
                    runOnUiThread {
                        blockedCount++
                        updateBadge()
                    }
                    return AdBlockEngine.createEmptyResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                url?.let { urlInput.setText(it) }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (adblockEnabled) {
                    view?.evaluateJavascript(AdBlockEngine.WHITE_BAR_COLLAPSER_JS, null)
                }
            }
        }

        urlInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                loadUserUrl(urlInput.text.toString())
                true
            } else {
                false
            }
        }

        switchAdblock.setOnCheckedChangeListener { _, isChecked ->
            adblockEnabled = isChecked
            webView.reload()
        }

        btnTapRemove.setOnClickListener {
            Toast.makeText(
                this,
                "Tik nu op een witte balk op de pagina om die weg te halen",
                Toast.LENGTH_SHORT
            ).show()
            webView.evaluateJavascript("window.__enableCleanBlockTapMode && window.__enableCleanBlockTapMode();", null)
        }

        val initialUrl = intent?.dataString ?: "https://nos.nl"
        loadUserUrl(initialUrl)
    }

    private fun loadUserUrl(rawInput: String) {
        val trimmed = rawInput.trim()
        val finalUrl = when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
            else -> "https://duckduckgo.com/?q=${Uri.encode(trimmed)}"
        }
        webView.loadUrl(finalUrl)
    }

    private fun updateBadge() {
        statsBadge.text = "🛡️ $blockedCount"
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
