package org.cleanblock.android

import android.net.Uri
import java.io.ByteArrayInputStream
import android.webkit.WebResourceResponse

object AdBlockEngine {

    // Bekende advertentie- en trackingdomeinen
    private val BLOCKED_DOMAINS = setOf(
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "adservice.google.com",
        "pagead2.googlesyndication.com",
        "adnxs.com",
        "criteo.com",
        "criteo.net",
        "outbrain.com",
        "taboola.com",
        "rubiconproject.com",
        "pubmatic.com",
        "openx.net",
        "smartadserver.com",
        "adform.net",
        "teads.tv",
        "moatads.com",
        "amazon-adsystem.com",
        "scorecardresearch.com",
        "zedo.com"
    )

    fun isAdUrl(url: String): Boolean {
        return try {
            val host = Uri.parse(url).host?.lowercase() ?: return false
            BLOCKED_DOMAINS.any { domain ->
                host == domain || host.endsWith(".$domain")
            }
        } catch (e: Exception) {
            false
        }
    }

    fun createEmptyResponse(): WebResourceResponse {
        return WebResourceResponse(
            "text/plain",
            "utf-8",
            ByteArrayInputStream("".toByteArray())
        )
    }

    // JavaScript dat in elke geladen Android WebView-pagina wordt geïnjecteerd om witte balken in te klappen
    val WHITE_BAR_COLLAPSER_JS = """
        (function() {
            if (window.__cleanBlockInjected) return;
            window.__cleanBlockInjected = true;

            const AD_SELECTORS = [
                'ins.adsbygoogle',
                'div[id^="div-gpt-ad"]',
                'div[id^="google_ads_iframe_"]',
                'iframe[src*="doubleclick.net"]',
                'iframe[src*="googlesyndication.com"]',
                '[data-ad-slot]',
                '[data-ad-unit]',
                '[data-google-query-id]',
                '[class*="ad-container"]',
                '[class*="ad-wrapper"]',
                '[class*="ad-slot"]',
                '[class*="ad-placeholder"]',
                '[id*="ad-container"]',
                '[id*="ad_wrapper"]',
                '[class*="advertentie"]',
                '[id*="advertentie"]',
                '.taboola-wrapper',
                '.outbrain-wrapper'
            ];

            // Voeg direct cosmetische CSS toe
            const style = document.createElement('style');
            style.textContent = AD_SELECTORS.join(',') + ' { display: none !important; height: 0 !important; min-height: 0 !important; margin: 0 !important; padding: 0 !important; }';
            (document.head || document.documentElement).appendChild(style);

            function collapseElement(el) {
                if (!el || el.dataset.cbHidden === '1') return;
                el.dataset.cbHidden = '1';
                el.style.setProperty('display', 'none', 'important');
                el.style.setProperty('height', '0px', 'important');
                el.style.setProperty('min-height', '0px', 'important');
                el.style.setProperty('margin', '0px', 'important');
                el.style.setProperty('padding', '0px', 'important');
                if (window.AndroidCleanBlock) {
                    window.AndroidCleanBlock.onWhiteBarCollapsed();
                }
            }

            function collapseEmptyParents(el) {
                let parent = el.parentElement;
                let depth = 0;
                while (parent && parent !== document.body && depth < 4) {
                    const tag = parent.tagName.toLowerCase();
                    if (['main', 'article', 'header', 'footer', 'nav', 'section'].includes(tag)) break;

                    const text = (parent.innerText || '').trim().toLowerCase();
                    const isAdLabelOnly = ['', 'advertentie', 'advertisement', 'gesponsord', 'sponsored', 'ad'].includes(text);
                    const hasContent = Array.from(parent.querySelectorAll('img[src], video, p, h1, h2, h3, a'))
                        .some(c => c.offsetParent !== null && !el.contains(c));

                    if (isAdLabelOnly && !hasContent) {
                        const target = parent;
                        parent = parent.parentElement;
                        collapseElement(target);
                        depth++;
                    } else {
                        const style = window.getComputedStyle(parent);
                        if (parseInt(style.minHeight, 10) >= 50 && isAdLabelOnly) {
                            parent.style.setProperty('min-height', '0px', 'important');
                            parent.style.setProperty('height', 'auto', 'important');
                        }
                        break;
                    }
                }
            }

            function scanDOM() {
                document.querySelectorAll(AD_SELECTORS.join(',')).forEach(el => {
                    collapseElement(el);
                    collapseEmptyParents(el);
                });

                document.querySelectorAll('div, aside, ins').forEach(box => {
                    if (box.dataset.cbHidden === '1') return;
                    const idClass = ((box.id || '') + ' ' + (box.className || '')).toLowerCase();
                    if (/\b(ad|ads|adv|advert|advertentie|dfp|gpt|banner|sponsor)\b/.test(idClass)) {
                        const text = (box.innerText || '').trim().toLowerCase();
                        const hasMedia = box.querySelector('img[src], video, p, article');
                        if (!hasMedia && ['', 'advertentie', 'advertisement', 'gesponsord'].includes(text)) {
                            collapseElement(box);
                            collapseEmptyParents(box);
                        }
                    }
                });
            }

            // Handmatige 'Tik op een witte balk om te verwijderen' modus voor Android
            window.__enableCleanBlockTapMode = function() {
                const handler = function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    collapseElement(e.target);
                    collapseEmptyParents(e.target);
                    document.removeEventListener('click', handler, true);
                };
                document.addEventListener('click', handler, true);
            };

            scanDOM();
            const observer = new MutationObserver(scanDOM);
            observer.observe(document.documentElement, { childList: true, subtree: true });
        })();
    """.trimIndent()
}
