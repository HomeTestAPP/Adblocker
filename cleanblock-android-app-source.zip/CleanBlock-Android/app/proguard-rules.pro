# CleanBlock Open-Source ProGuard Rules
-keepattributes *Annotation*,InnerClasses,Signature
